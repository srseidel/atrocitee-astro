-- Run this in Supabase SQL editor to verify user roles
SELECT id, email, role 
FROM profiles
ORDER BY role; 